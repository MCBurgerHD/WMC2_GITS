function getTheTitles() {
    console.log(document.title)
}

// Do not edit below this line
module.exports = getTheTitles;
