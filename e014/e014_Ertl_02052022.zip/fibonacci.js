function fibonacci(number) {
    var a,b,s,i;
    a=0;
    b=1;
    s=b+a;
    for (i=2; i < 40; i++){
    document.write("i= " + i + "<br>");
    }
}



// Do not edit below this line
module.exports = fibonacci;
