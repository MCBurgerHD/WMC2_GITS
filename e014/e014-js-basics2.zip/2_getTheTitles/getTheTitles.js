function getTheTitles() {

}

// Do not edit below this line
module.exports = getTheTitles;
