let button = document.getElementsByTagName("button")

for (let i = 0; i < 9; i++) {
    button.addEventListener("onclick", farbeBlau())

    button.addEventListener("onclick", farbeRot())

    function farbeBlau() {
        document.bgColor = "#00FF00";
        document.getElementsByTagName("button")[0].style.backgroundColor = document.bgColor;
        document.form1.bgfarbe.value = document.bgColor;
    }

    function farbeRot() {
        document.bgColor = "#FF0000";
        document.getElementsByTagName("button")[0].style.backgroundColor = document.bgColor;
        document.form1.bgfarbe.value = document.bgColor;
    }
}