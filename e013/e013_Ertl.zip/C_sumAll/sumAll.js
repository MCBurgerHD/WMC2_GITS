function sumAll(a, b) {
    sum = 0;
    for (i = 0; i < b; i++) {
        sum += a
        a++
    }
    return sum
}

console.log(sumAll(1,4))

// Do not edit below this line
module.exports = sumAll;
