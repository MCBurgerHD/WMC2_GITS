function add(zahl1, zahl2) {
    return zahl1 + zahl2
}

function subtract(zahl1, zahl2) {
    return zahl1 - zahl2
}

function sum(array) {
    summe = 0
    for (i = 0; i < array.length; i++) {
        summe += array[i]
    }
    return summe
}

function multiply(array) {
    mult = 1
    for (i = 0; i < array.length; i++) {
        mult = mult * array[i]
    }
    return mult
}

function power(zahl) {
    powerergebnis = 0
    for (i = 0; i < zahl; i++) {
        powerergebnis += zahl * zahl
    }
    return powerergebnis
}

function factorial() {
    ergebnis = 1;
    if (n == 0 || n == 1) {
        return ergebnis;
    }
    else {
        for (i = n; i >= 1; i--) {
            rergebnis = ergebnis * i;
        }
        return ergebnis;
    }

}

// Do not edit below this line
module.exports = {
    add,
    subtract,
    sum,
    multiply,
    power,
    factorial
};
