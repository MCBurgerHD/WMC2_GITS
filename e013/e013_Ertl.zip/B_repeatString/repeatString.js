function repeatString(text, times) {
    for (i = 0; i < times; i++) {
        console.log(text)
    };
}

repeatString("Hallo", 3)

// Do not edit below this line
module.exports = repeatString;
