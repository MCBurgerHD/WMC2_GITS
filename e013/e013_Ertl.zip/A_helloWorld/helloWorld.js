function helloWorld() {
  return 'Hello World'
};

console.log(helloWorld())

module.exports = helloWorld;
