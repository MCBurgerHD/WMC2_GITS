function helloWorld() {
  return ''
};

module.exports = helloWorld;
