function repeatString(text, times) {
}

// Do not edit below this line
module.exports = repeatString;
