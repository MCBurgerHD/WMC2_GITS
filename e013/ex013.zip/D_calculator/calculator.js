function add() {
	
}

function subtract() {
	
}

function sum() {
	
}

function multiply() {

}

function power() {
	
}

function factorial() {
	
}

// Do not edit below this line
module.exports = {
  add,
  subtract,
  sum,
  multiply,
  power,
  factorial
};
