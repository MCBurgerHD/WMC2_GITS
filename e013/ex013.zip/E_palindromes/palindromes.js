function palindromes() {
}

// Do not edit below this line
module.exports = palindromes;
